#!/bin/bash

zip -r "bot_fakturama.zip" * -x "bot_fakturama.zip"